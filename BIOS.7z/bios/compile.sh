#!/bin/bash

rm ./*.rel
rm ./bnkbios3.spr
rm ./cpmldr.com

#cpmldr
zxcc rmac ldrbios
zxcc rmac cpmldr3
zxcc link cpmldr=cpmldr3,ldrbios

#core
zxcc rmac bioskrnl
zxcc rmac boot
zxcc rmac chario
zxcc rmac move
zxcc rmac scb
zxcc rmac move
zxcc rmac vdisk

zxcc link bnkbios3 +-[B] +-= +bioskrnl,scb,boot,chario,move,vdisk

cp ./bnkbios3.spr ../build-bios/bnkbios3.spr
