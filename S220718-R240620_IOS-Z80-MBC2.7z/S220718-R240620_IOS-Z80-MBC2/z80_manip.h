#include <avr/io.h>
#include <Arduino.h>
#include "hardware.h"


const byte    LD_HL        =  0x36;       // Opcode of the Z80 instruction: LD(HL), n
const byte    INC_HL       =  0x23;       // Opcode of the Z80 instruction: INC HL
const byte    LD_HLnn      =  0x21;       // Opcode of the Z80 instruction: LD HL, nn
const byte    JP_nn        =  0xC3;       // Opcode of the Z80 instruction: JP nn
const byte    LD_A_HL      =  0x7E;
const String  compTimeStr  = __TIME__;    // Compile timestamp string
const String  compDateStr  = __DATE__;    // Compile datestamp string
const byte    daysOfMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
//const byte    debug        = 0;           // Debug off = 0, on = 1, on = 2 with interrupt trace
const byte    bootModeAddr = 10;          // Internal EEPROM address for boot mode storage
const byte    autoexecFlagAddr = 12;      // Internal EEPROM address for AUTOEXEC flag storage
const byte    clockModeAddr = 13;         // Internal EEPROM address for the Z80 clock high/low speed switch
                                          //  (1 = low speed, 0 = high speed)
const byte    diskSetAddr  = 14;          // Internal EEPROM address for the current Disk Set [0..9]
const byte    maxDiskNum   = 99;          // Max number of virtual disks
const byte    maxDiskSet   = 5;           // Number of configured Disk Sets



void pulseClock(byte numPulse); // Generate <numPulse> clock pulses on the Z80 clock pin.
void loadByteToRAM(byte value); // Load a given byte to RAM using a sequence of two Z80 instructions forced on the data bus.
byte getByteFromRAM();
void loadHL(word value); // Load "value" word into the HL registers inside the Z80 CPU, using the "LD HL,nn" instruction.
void incHL(); // Execute the INC(HL) instruction (T = 6). See the Z80 datasheet and manual.
void singlePulsesResetZ80(); // Reset the Z80 CPU using single pulses clock

//void exitIOTransmission();



/*
  void portWrite(int pin, int state) {
  if (state == 1) { //write HIGH
    switch (pin) {
      case 0: PORTD = PORTD | 0x01; break;
      case 1: PORTD = PORTD | 0x02; break;
      case 2: PORTD = PORTD | 0x04; break;
      case 3: PORTD = PORTD | 0x08; break;
      case 4: PORTD = PORTD | 0x10; break;
      case 5: PORTD = PORTD | 0x20; break;
      case 6: PORTD = PORTD | 0x40; break;
      case 7: PORTD = PORTD | 0x80; break;
      case 8: PORTB = PORTB | 0x01; break;
      case 9: PORTB = PORTB | 0x02; break;
      case 10: PORTB = PORTB | 0x04; break;
      case 11: PORTB = PORTB | 0x08; break;
      case 12: PORTB = PORTB | 0x10; break;
      case 13: PORTB = PORTB | 0x20; break;
      case 14: PORTC = PORTC | 0x01; break;
      case 15: PORTC = PORTC | 0x02; break;
      case 16: PORTC = PORTC | 0x04; break;
      case 17: PORTC = PORTC | 0x08; break;
      case 18: PORTC = PORTC | 0x10; break;
      case 19: PORTC = PORTC | 0x20; break;
    }
  } else {// write low
    switch (pin) {
      case 0: PORTD = PORTD & 0xFE; break;
      case 1: PORTD = PORTD & 0xFD; break;
      case 2: PORTD = PORTD & 0xFB; break;
      case 3: PORTD = PORTD & 0xF7; break;
      case 4: PORTD = PORTD & 0xEF; break;
      case 5: PORTD = PORTD & 0xDF; break;
      case 6: PORTD = PORTD & 0xBF; break;
      case 7: PORTD = PORTD & 0x7F; break;
      case 8: PORTB = PORTB & 0xFE; break;
      case 9: PORTB = PORTB & 0xFD; break;
      case 10: PORTB = PORTB & 0xFB; break;
      case 11: PORTB = PORTB & 0xF7; break;
      case 12: PORTB = PORTB & 0xEF; break;
      case 13: PORTB = PORTB & 0xDF; break;
      case 14: PORTC = PORTC & 0xFE; break;
      case 15: PORTC = PORTC & 0xFD; break;
      case 16: PORTC = PORTC & 0xFB; break;
      case 17: PORTC = PORTC & 0xF7; break;
      case 18: PORTC = PORTC & 0xEF; break;
      case 19: PORTC = PORTC & 0xDF; break;
    }
  }
  }

*/
