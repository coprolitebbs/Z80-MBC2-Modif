#include "z80_manip.h"
#include "hardware.h"


void pulseClock(byte numPulse)
// Generate <numPulse> clock pulses on the Z80 clock pin.
// The steady clock level is LOW, e.g. one clock pulse is a 0-1-0 transition
{
  byte    i;
  for (i = 0; i < numPulse; i++)
    // Generate one clock pulse
  {
    // Send one impulse (0-1-0) on the CLK output
    //digitalWrite(CLK, HIGH);
    PORTD = PORTD | 0x80;
    //digitalWrite(CLK, LOW);
    PORTD = PORTD & 0x7F;
  }
}



void loadByteToRAM(byte value)
// Load a given byte to RAM using a sequence of two Z80 instructions forced on the data bus.
// The RAM_CE2 signal is used to force the RAM in HiZ, so the Atmega can write the needed instruction/data
//  on the data bus. Controlling the clock signal and knowing exactly how many clocks pulse are required it
//  is possible control the whole loading process.
// In the following "T" are the T-cycles of the Z80 (See the Z80 datashet).
// The two instruction are "LD (HL), n" and "INC (HL)".
{

  // Execute the LD(HL),n instruction (T = 4+3+3). See the Z80 datasheet and manual.
  // After the execution of this instruction the <value> byte is loaded in the memory address pointed by HL.
  pulseClock(1);                      // Execute the T1 cycle of M1 (Opcode Fetch machine cycle)
  //digitalWrite(RAM_CE2, LOW);         // Force the RAM in HiZ (CE2 = LOW)
  PORTB = PORTB & 0xFB;
  DDRA = 0xFF;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as output
  PORTA = LD_HL;                      // Write "LD (HL), n" opcode on data bus
  pulseClock(2);                      // Execute T2 and T3 cycles of M1
  DDRA = 0x00;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as input...
  PORTA = 0xFF;                       // ...with pull-up
  pulseClock(2);                      // Complete the execution of M1 and execute the T1 cycle of the following
  // Memory Read machine cycle
  DDRA = 0xFF;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as output
  PORTA = value;                      // Write the byte to load in RAM on data bus
  pulseClock(2);                      // Execute the T2 and T3 cycles of the Memory Read machine cycle
  DDRA = 0x00;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as input...
  PORTA = 0xFF;                       // ...with pull-up
  //digitalWrite(RAM_CE2, HIGH);        // Enable the RAM again (CE2 = HIGH)
  PORTB = PORTB | 0x04;
  pulseClock(3);                      // Execute all the following Memory Write machine cycle

  // Execute the INC(HL) instruction (T = 6). See the Z80 datasheet and manual.
  // After the execution of this instruction HL points to the next memory address.
  pulseClock(1);                      // Execute the T1 cycle of M1 (Opcode Fetch machine cycle)
  //digitalWrite(RAM_CE2, LOW);         // Force the RAM in HiZ (CE2 = LOW)
  PORTB = PORTB & 0xFB;
  DDRA = 0xFF;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as output
  PORTA = INC_HL;                     // Write "INC(HL)" opcode on data bus
  pulseClock(2);                      // Execute T2 and T3 cycles of M1
  DDRA = 0x00;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as input...
  PORTA = 0xFF;                       // ...with pull-up
  //digitalWrite(RAM_CE2, HIGH);        // Enable the RAM again (CE2 = HIGH)
  PORTB = PORTB | 0x04;
  pulseClock(3);                      // Execute all the remaining T cycles
}



byte getByteFromRAM()
{
  byte out;
  // Execute the LD A,(HL) instruction. See the Z80 datasheet and manual.
  pulseClock(1);                      // Execute the T1 cycle of M1 (Opcode Fetch machine cycle)
  //digitalWrite(RAM_CE2, LOW);         // Force the RAM in HiZ (CE2 = LOW)
  PORTB = PORTB & 0xFB;
  DDRA = 0xFF;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as output
  PORTA = LD_A_HL;                    // Write "LD A, (HL)" opcode on data bus
  pulseClock(2);                      // Execute T2 and T3 cycles of M1
  //digitalWrite(RAM_CE2, HIGH);
  PORTB = PORTB | 0x04;
  DDRA = 0x00;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as input...
  PORTA = 0xFF;                       // ...with pull-up
  pulseClock(2);                      // Complete the execution of M1 and execute the T1 cycle of the following
  out = PINA;                         // Read a byte from RAM on data bus
  pulseClock(2);                      // Execute the T2 and T3 cycles of the Memory Read machine cycle

  incHL();

  return out;
}



void loadHL(word value)
// Load "value" word into the HL registers inside the Z80 CPU, using the "LD HL,nn" instruction.
// In the following "T" are the T-cycles of the Z80 (See the Z80 datashet).
{
  // Execute the LD dd,nn instruction (T = 4+3+3), with dd = HL and nn = value. See the Z80 datasheet and manual.
  // After the execution of this instruction the word "value" (16bit) is loaded into HL.
  pulseClock(1);                      // Execute the T1 cycle of M1 (Opcode Fetch machine cycle)
  //digitalWrite(RAM_CE2, LOW);         // Force the RAM in HiZ (CE2 = LOW)
  PORTB = PORTB & 0xFB;
  DDRA = 0xFF;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as output
  PORTA = LD_HLnn;                    // Write "LD HL, n" opcode on data bus
  pulseClock(2);                      // Execute T2 and T3 cycles of M1
  DDRA = 0x00;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as input...
  PORTA = 0xFF;                       // ...with pull-up
  pulseClock(2);                      // Complete the execution of M1 and execute the T1 cycle of the following
  // Memory Read machine cycle
  DDRA = 0xFF;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as output
  PORTA = lowByte(value);             // Write first byte of "value" to load in HL
  pulseClock(3);                      // Execute the T2 and T3 cycles of the first Memory Read machine cycle
  // and T1, of the second Memory Read machine cycle
  PORTA = highByte(value);            // Write second byte of "value" to load in HL
  pulseClock(2);                      // Execute the T2 and T3 cycles of the second Memory Read machine cycle
  DDRA = 0x00;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as input...
  PORTA = 0xFF;                       // ...with pull-up
  //digitalWrite(RAM_CE2, HIGH);        // Enable the RAM again (CE2 = HIGH)
  PORTB = PORTB | 0x04;
}


void incHL()
{
  // Execute the INC(HL) instruction (T = 6). See the Z80 datasheet and manual.
  // After the execution of this instruction HL points to the next memory address.
  pulseClock(1);                      // Execute the T1 cycle of M1 (Opcode Fetch machine cycle)
  //digitalWrite(RAM_CE2, LOW);         // Force the RAM in HiZ (CE2 = LOW)
  PORTB = PORTB & 0xFB;
  DDRA = 0xFF;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as output
  PORTA = INC_HL;                     // Write "INC(HL)" opcode on data bus
  pulseClock(2);                      // Execute T2 and T3 cycles of M1
  DDRA = 0x00;                        // Configure Z80 data bus D0-D7 (PA0-PA7) as input...
  PORTA = 0xFF;                       // ...with pull-up
  //digitalWrite(RAM_CE2, HIGH);        // Enable the RAM again (CE2 = HIGH)
  PORTB = PORTB | 0x04;
  pulseClock(3);                      // Execute all the remaining T cycles
}




void singlePulsesResetZ80()
// Reset the Z80 CPU using single pulses clock
{
  //digitalWrite(RESET_, LOW);          // Set RESET_ active
  PORTC = PORTC & 0xBF;
  pulseClock(/*6*/6);                      // Generate twice the needed clock pulses to reset the Z80
  //digitalWrite(RESET_, HIGH);         // Set RESET_ not active
  PORTC = PORTC | 0x40;
  pulseClock(/*2*/2);                      // Needed two more clock pulses after RESET_ goes HIGH
}
